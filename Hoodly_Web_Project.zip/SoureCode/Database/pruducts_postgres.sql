-- ==========================================
-- products.sql
-- Create and populate products table
-- PostgreSQL compatible
-- ==========================================

BEGIN;

DROP TABLE IF EXISTS products;

CREATE TABLE products (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    short_description TEXT,
    price NUMERIC(10,2),
    image_url TEXT,
    featured BOOLEAN,
    details TEXT,
    category TEXT
);

INSERT INTO products (id, name, short_description, price, image_url, featured, details, category) VALUES
(1, 'Blue Heart Hoodie', 'Soft blue hoodie with a minimalist heart design.', 39.99, '/images/hoodie-blue-heart.jpg', TRUE, '80% Cotton, 20% Polyester. High-quality fleece interior.', 'NEW DROPS'),
(2, 'Urban Street Fashion', 'Modern urban style hoodie for everyday wear.', 45.00, '/images/hoodie-urban-style.jpg', TRUE, 'Oversized fit, durable fabric, screen-printed logo.', 'NEW DROPS'),
(10, 'Black Mushroom Art', 'Unique nature-inspired mushroom graphic.', 47.50, '/images/hoodie-black-mushroom.jpg', FALSE, 'Detailed artwork, comfortable fit, streetwear inspired.', 'NEW DROPS'),
(4, 'Cute Boba Bear', 'Adorable bear illustration with a boba tea theme.', 42.50, '/images/hoodie-boba-bear.jpg', FALSE, 'Soft-touch fabric, cute aesthetic, perfect for casual wear.', 'NEW DROPS'),
(5, 'Brown Butterfly Illustration', 'Elegant butterfly art on a chocolate brown base.', 48.00, '/images/hoodie-brown-butterfly.jpg', FALSE, 'Eco-friendly dyes, relaxed fit, hand-drawn illustration.', 'GRAPHICS'),
(7, 'Panda Headphones Hoodie', 'Cool panda character wearing headphones.', 46.00, '/images/hoodie-panda-headphones.jpg', FALSE, 'Modern graphic, high-quality knit, comfortable fit.', 'GRAPHICS'),
(3, 'Purple Wings Graphic', 'Stylized angel wings graphic on purple base.', 44.00, '/images/hoodie-purple-wings.jpg', FALSE, 'Premium heavy cotton, vivid graphic print.', 'GRAPHICS'),
(6, 'Black Skeleton Graphic', 'Edgy skeleton artwork on black hoodie.', 49.00, '/images/hoodie-black-skeleton.jpg', FALSE, 'Edgy style, durable print, breathable material.', 'GRAPHICS'),
(12, 'Pink Dream Graphic', 'Dreamy pink aesthetic with playful art.', 43.00, '/images/hoodie-pink-dream.jpg', FALSE, 'Vibrant color, lightweight fleece, playful design.', 'GRAPHICS'),
(13, 'Brown Teddy Bear', 'Cute teddy bear illustration in warm brown.', 41.50, '/images/hoodie-brown-teddy.jpg', FALSE, 'Warm lining, adorable graphic, classic teddy look.', 'NEW DROPS'),
(14, 'Black New York Style', 'New York typography streetwear style.', 50.00, '/images/hoodie-black-ny.jpg', FALSE, 'City aesthetic, bold typography, premium streetwear.', 'NEW DROPS'),
(15, 'Blue Rabbit Slogan', 'Rabbit graphic with inspirational slogan.', 44.50, '/images/hoodie-blue-rabbit.jpg', FALSE, 'Creative typography, relaxed shoulders, durable print.', 'NEW DROPS'),
(8, 'Dark Blue Minimalist', 'Minimalist design in deep blue tone.', 38.00, '/images/hoodie-dark-blue-minimal.jpg', FALSE, 'Minimalist aesthetic, versatile style, soft interior.', 'ESSENTIALS'),
(9, 'Blue Night Graphic', 'Night-themed graphic with stars and moon.', 45.50, '/images/hoodie-blue-night.jpg', FALSE, 'Artistic print, ribbed cuffs, premium finish.', 'ESSENTIALS'),
(11, 'Beige Flower Graphic', 'Subtle floral graphic on beige base.', 40.00, '/images/hoodie-beige-flower.jpg', FALSE, 'Subtle design, organic cotton blend, soft colors.', 'ESSENTIALS'),
(17, 'Nirvana Angel Graphic', 'Angel artwork inspired by grunge aesthetic.', 52.00, '/images/hoodie-nirvana-angel.jpg', FALSE, 'Rock aesthetic, high-density print, vintage feel.', 'GRAPHICS'),
(16, 'Green Forest Graphic', 'Nature-inspired forest illustration.', 46.50, '/images/hoodie-green-forest.jpg', FALSE, 'Deep green color, soft texture, artistic graphic.', 'GRAPHICS'),
(18, 'Galaxy Explorer', 'Space-themed hoodie with galaxy print.', 53.00, '/images/hoodie-galaxy.jpg', FALSE, 'Space theme, glow-in-the-dark elements, premium fabric.', 'GRAPHICS'),
(19, 'Classic Thermal Hoodie', 'Warm minimalist hoodie for winter.', 55.00, '/images/hoodie-thermal.jpg', FALSE, 'Thermal lining for extra warmth, minimalist look.', 'ESSENTIALS'),
(20, 'Sunny Day Graphic', 'Bright cheerful hoodie with sunny graphic.', 42.00, '/images/hoodie-sunny.jpg', FALSE, 'Bright aesthetic, comfortable fit, trendy design.', 'ESSENTIALS'),
(21, 'Classic Essentials Hoodie', 'Rich color, minimalist style, perfect for layering.', 37.00, '/images/hoodie-classic.jpg', FALSE, 'Everyday essential, soft fabric, clean look.', 'ESSENTIALS');

COMMIT;
