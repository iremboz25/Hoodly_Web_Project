import Profile from "./pages/Profile";
import React from "react";
import Header from "./components/Header";
import Footer from "./components/Footer"; // 1. Import Footer
import Home from "./pages/Home";
import Checkout from "./pages/Checkout";
import ProductDetail from "./pages/ProductDetail";
import { CartProvider } from "./context/CartContext";
import { Routes, Route } from "react-router-dom";
import CategoryPage from "./pages/CategoryPage";
import "./App.css";
import { WishlistProvider } from './context/WishlistContext';
import PaymentPage from "./pages/PaymentPage";
import WishlistPage from "./pages/WishlistPage";
import { Box } from "@mui/material"; // For layout wrapper

function App() {
  return (
    <WishlistProvider>
      <CartProvider>
        {/* Main Layout Wrapper:
          'minHeight: 100vh' and 'flexDirection: column'
          ensures the Footer stays at the bottom of the screen.
        */}
        <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
          <Header />

          {/* Main Content Area: 'flex: 1' pushes the footer down */}
          <Box component="main" sx={{ flex: 1 }}>
            <Routes>
              <Route path="/profile" element={<Profile />} />
              <Route path="/" element={<Home />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/products/:id" element={<ProductDetail />} />

              {/* Category Routes - Values matching backend logic */}
              <Route path="/all-products" element={<CategoryPage categoryName="All Products" />} />
              <Route path="/new-drops" element={<CategoryPage categoryName="NEW DROPS" />} />
              <Route path="/essentials" element={<CategoryPage categoryName="ESSENTIALS" />} />
              <Route path="/graphics" element={<CategoryPage categoryName="GRAPHICS" />} />
              <Route path="/payment" element={<PaymentPage />} />
              <Route path="/wishlist" element={<WishlistPage />} />

            </Routes>
          </Box>

          <Footer /> {/* 2. Add Footer here */}
        </Box>
      </CartProvider>
    </WishlistProvider>
  );
}

export default App;