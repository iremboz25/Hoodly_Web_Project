import React from "react";
import { Container, Grid, Typography, Box, Button, Divider } from "@mui/material";
import { useWishlist } from "../context/WishlistContext";
import ProductCard from "../components/ProductCard";
import { Link } from "react-router-dom";

export default function WishlistPage() {
  const { wishlistItems } = useWishlist();

  return (
    <Container sx={{ py: 8 }}>
      <Typography variant="h4" sx={{ fontWeight: 900, mb: 1, color: "white" }}>
        MY WISHLIST
      </Typography>
      <Typography variant="body1" sx={{ color: "gray", mb: 4 }}>
        {wishlistItems.length} items saved
      </Typography>

      <Divider sx={{ bgcolor: "#333", mb: 5 }} />

      {wishlistItems.length === 0 ? (
        <Box sx={{ textAlign: 'center', py: 10 }}>
          <Typography variant="h6" sx={{ color: "white", mb: 2 }}>
            Your wishlist is empty.
          </Typography>
          <Button
            variant="outlined"
            component={Link}
            to="/all-products"
            sx={{ color: "white", borderColor: "white", borderRadius: 0 }}
          >
            RETURN TO SHOP
          </Button>
        </Box>
      ) : (
        <Grid container spacing={3}>
          {wishlistItems.map((product) => (
            <Grid item key={product.id} xs={12} sm={6} md={4} lg={3}>
              <ProductCard product={product} />
            </Grid>
          ))}
        </Grid>
      )}
    </Container>
  );
}