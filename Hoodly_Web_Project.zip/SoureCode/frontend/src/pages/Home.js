import React from "react";
import { Box, Typography, Button, Container } from "@mui/material";
import { Link } from "react-router-dom";

export default function Home() {
  // Çalışan tek resim linki ve slogan
  const heroData = {
    img: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=1974",
    slogan: "UNMATCHED COMFORT, URBAN STYLE."
  };

  return (
    <Box
      sx={{
        width: "100%",
        height: "90vh",
        position: "relative",
        overflow: "hidden",
        bgcolor: "black"
      }}
    >
      {/* Arka Plan Resmi */}
      <Box
        sx={{
          height: "100%",
          backgroundImage: `url(${heroData.img})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          "&::before": {
            content: '""',
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0,0,0,0.5)", // Koyu overlay (yazılar okunsun diye)
          }
        }}
      >
        {/* İçerik */}
        <Container sx={{ position: "relative", zIndex: 1, textAlign: "center", color: "white" }}>
          <Typography
            variant="h1"
            sx={{
              fontWeight: 900,
              letterSpacing: "12px",
              fontSize: { xs: "3.5rem", md: "6rem" },
              mb: 1
            }}
          >
            HOODLY
          </Typography>

          <Typography
            variant="h5"
            sx={{
              fontWeight: 300,
              letterSpacing: "4px",
              mb: 6,
              fontStyle: "italic",
              fontSize: { xs: "1.2rem", md: "1.8rem" }
            }}
          >
            {heroData.slogan}
          </Typography>

          <Button
            variant="outlined"
            size="large"
            component={Link}
            to="/all-products"
            sx={{
              color: "white",
              borderColor: "white",
              borderWidth: "2px",
              px: 6,
              py: 1.5,
              borderRadius: 0,
              fontWeight: "bold",
              transition: "0.3s",
              "&:hover": {
                bgcolor: "white",
                color: "black",
                borderColor: "white"
              }
            }}
          >
            DISCOVER NOW
          </Button>
        </Container>
      </Box>
    </Box>
  );
}