import React from "react";
import {
  Container, Grid, Typography, TextField, Button,
  Box, Divider
} from "@mui/material";
import { useCart } from "../context/CartContext";

export default function PaymentPage() {
  const cartContext = useCart();
  const cartItems = cartContext?.cartItems || [];
  const clearCart = cartContext?.clearCart || (() => {});

  // Calculate total price for the payment button
  const totalPrice = cartItems.reduce((acc, item) => acc + (item.price * (item.quantity || 1)), 0);

  const handlePayment = (e) => {
    e.preventDefault();

    alert("Payment Successful! Your order has been placed.");
    clearCart();
    window.location.href = "/";
  };

  return (
    <Container maxWidth="sm" sx={{ py: 10 }}>
      <Typography variant="h4" sx={{ fontWeight: 900, mb: 6, letterSpacing: '2px', textAlign: 'center' }}>
        CHECKOUT
      </Typography>


      <Box
        component="form"
        onSubmit={handlePayment}
        autoComplete="off"
      >
        {/* 1. SHIPPING DETAILS SECTION */}
        <Typography variant="h6" sx={{ fontWeight: 800, mb: 3, fontSize: '0.9rem', letterSpacing: '1px' }}>
          1. SHIPPING DETAILS
        </Typography>
        <Grid container spacing={3}>
          <Grid item xs={12} sm={6}>
            <TextField fullWidth label="First Name" variant="standard" required />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField fullWidth label="Last Name" variant="standard" required />
          </Grid>
          <Grid item xs={12}>
            <TextField fullWidth label="Street Address" variant="standard" required />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField fullWidth label="City" variant="standard" required />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField fullWidth label="Country" variant="standard" required />
          </Grid>
        </Grid>

        <Divider sx={{ my: 6 }} />

        {/* 2. PAYMENT METHOD SECTION */}
        <Typography variant="h6" sx={{ fontWeight: 800, mb: 3, fontSize: '0.9rem', letterSpacing: '1px' }}>
          2. PAYMENT METHOD
        </Typography>
        <Grid container spacing={3}>
          <Grid item xs={12}>

            <TextField
              fullWidth
              label="Cardholder Name"
              variant="standard"
              placeholder="e.g. John Doe"
              required
              inputProps={{ autoComplete: "new-password" }}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Card Number"
              variant="standard"
              placeholder="0000 0000 0000 0000"
              required
              inputProps={{ autoComplete: "new-password" }}
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              fullWidth
              label="Expiry Date"
              variant="standard"
              placeholder="MM/YY"
              required
              inputProps={{ autoComplete: "new-password" }}
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              fullWidth
              label="CVV"
              variant="standard"
              placeholder="***"
              required
              inputProps={{ autoComplete: "new-password" }}
            />
          </Grid>
        </Grid>

        {/* Purchase Action */}
        <Box sx={{ mt: 8, textAlign: 'center' }}>
          <Button
            type="submit"
            variant="contained"
            fullWidth
            sx={{
              py: 2,
              bgcolor: 'black',
              color: 'white',
              fontWeight: 900,
              borderRadius: 0,
              fontSize: '1rem',
              '&:hover': { bgcolor: '#333' }
            }}
          >
            COMPLETE PURCHASE — ${totalPrice.toFixed(2)}
          </Button>
          <Typography variant="caption" display="block" sx={{ mt: 2, color: 'gray' }}>
            Secure Encrypted Transaction
          </Typography>
        </Box>
      </Box>
    </Container>
  );
}