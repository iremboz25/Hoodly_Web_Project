import React, { useEffect, useState } from "react";
import { Container, Grid, Typography, Divider, Box } from "@mui/material";
import ProductCard from "../components/ProductCard";
import axios from "axios";
import { useLocation } from "react-router-dom"; // URL parametrelerini okumak için

export default function CategoryPage({ categoryName }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const location = useLocation();

  // URL'deki ?query=... kısmını alıyoruz
  const queryParams = new URLSearchParams(location.search);
  const searchQuery = queryParams.get("query")?.toLowerCase() || "";

  useEffect(() => {
    setLoading(true);
    axios.get("http://localhost:8080/api/products")
      .then((res) => {
        let filtered = res.data;

        // 1. Önce Kategoriye Göre Filtrele
        if (categoryName !== "All Products") {
          filtered = filtered.filter(p =>
            p.category && p.category.toUpperCase() === categoryName.toUpperCase()
          );
        }

        // 2. Eğer Arama Terimi Varsa İsme Göre Filtrele
        if (searchQuery) {
          filtered = filtered.filter(p =>
            p.name.toLowerCase().includes(searchQuery) ||
            (p.description && p.description.toLowerCase().includes(searchQuery))
          );
        }

        setProducts(filtered);
        setLoading(false);
      })
      .catch(err => {
        console.error("Fetch error:", err);
        setLoading(false);
      });
  }, [categoryName, searchQuery]); // Arama terimi veya kategori değişince tekrar çalışır

  return (
    <Container maxWidth="lg" sx={{ mt: 5, mb: 10 }}>
      <Typography variant="h4" sx={{ fontWeight: 800, mb: 1, color: "white" }}>
        {searchQuery ? `SEARCH RESULTS FOR: "${searchQuery.toUpperCase()}"` : categoryName}
      </Typography>

      <Typography variant="body2" sx={{ color: "gray", mb: 3 }}>
        {products.length} Products Found
      </Typography>

      <Divider sx={{ mb: 4, bgcolor: "#333" }} />

      {products.length === 0 && !loading ? (
        <Box sx={{ textAlign: "center", mt: 10 }}>
          <Typography variant="h6" sx={{ color: "gray" }}>
            No products match your search.
          </Typography>
        </Box>
      ) : (
        <Grid container spacing={3} alignItems="stretch">
          {products.map((product) => (
            <Grid item key={product.id} xs={12} sm={6} md={4} sx={{ display: 'flex' }}>
              <ProductCard product={product} />
            </Grid>
          ))}
        </Grid>
      )}
    </Container>
  );
}