import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom"; // URL'den gelen bilgiyi okumak için
import { Container, Typography, Box, Paper, Divider, Button } from "@mui/material";

export default function Profile() {
  const location = useLocation();
  // Varsayılan olarak 'info' (kişisel bilgiler) gösterilir
  const [view, setView] = useState("info");

  // Header'dan gelen yönlendirmeyi takip eder
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const section = params.get("view");
    if (section) {
      setView(section);
    }
  }, [location]);

  const user = {
    name: "Mary Jane Watson",
    email: "m.janewatson@gmail.com",
    orders: [
      { id: "#ORD-7721", date: "Jan 04, 2026", total: "$79.98", status: "Shipped" },
      { id: "#ORD-6542", date: "Dec 20, 2025", total: "$120.50", status: "Delivered" }
    ]
  };

  return (
    <Container maxWidth="md" sx={{ mt: 8, mb: 8 }}>
      <Typography variant="h4" sx={{ fontWeight: 900, mb: 4, letterSpacing: '-1px' }}>
        {view === "info" ? "MY ACCOUNT" : "ORDER HISTORY"}
      </Typography>

      <Box sx={{ width: '100%' }}>
        {/* SADECE PERSONAL INFO GÖSTERİLDİĞİ DURUM */}
        {view === "info" && (
          <Paper elevation={0} sx={{ p: 4, border: '1px solid #333', borderRadius: 0, bgcolor: '#fafafa', maxWidth: '400px' }}>
            <Typography variant="h6" sx={{ fontWeight: 800, mb: 2 }}>Personal Info</Typography>
            <Typography variant="body2" sx={{ mb: 1 }}><strong>Name:</strong> {user.name}</Typography>
            <Typography variant="body2" sx={{ mb: 3 }}><strong>Email:</strong> {user.email}</Typography>
            <Button variant="contained" fullWidth sx={{ bgcolor: 'black', borderRadius: 0, fontWeight: 700, '&:hover': { bgcolor: '#333' } }}>
              Edit Account
            </Button>
            <Button onClick={() => setView("orders")} sx={{ mt: 2, color: 'black', textDecoration: 'underline', textTransform: 'none' }}>
              View Order History
            </Button>
          </Paper>
        )}

        {/* SADECE ORDER HISTORY GÖSTERİLDİĞİ DURUM */}
        {view === "orders" && (
          <Paper elevation={0} sx={{ p: 4, border: '1px solid #333', borderRadius: 0 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 800 }}>Past Orders</Typography>
                <Button onClick={() => setView("info")} sx={{ color: 'black', textTransform: 'none' }}>← Back to Account</Button>
            </Box>
            {user.orders.map((order) => (
              <Box key={order.id} sx={{ mb: 3 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>{order.id}</Typography>
                  <Typography variant="caption" color="text.secondary">{order.date}</Typography>
                </Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography variant="body1" sx={{ fontWeight: 600 }}>{order.total}</Typography>
                  <Typography variant="body2" sx={{ color: '#2e7d32', fontWeight: 700 }}>{order.status}</Typography>
                </Box>
                <Divider sx={{ mt: 2 }} />
              </Box>
            ))}
          </Paper>
        )}
      </Box>
    </Container>
  );
}