import React from "react";
import { Box, Typography, IconButton, Container } from "@mui/material";
import InstagramIcon from '@mui/icons-material/Instagram';
import TwitterIcon from '@mui/icons-material/Twitter';
import FacebookIcon from '@mui/icons-material/Facebook';

/**
 * Footer Component
 * Provides social media links and copyright information.
 * Included globally in App.js.
 */
export default function Footer() {
  return (
    <Box component="footer" sx={{ bgcolor: '#121212', color: 'white', py: 6, mt: 'auto', borderTop: '1px solid #222' }}>
      <Container maxWidth="lg">
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <Typography variant="h6" sx={{ fontWeight: 900, letterSpacing: '3px', mb: 2 }}>
            HOODLY
          </Typography>

          <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
            <IconButton
              href="https://instagram.com"
              target="_blank"
              sx={{ color: 'white', '&:hover': { color: '#E1306C', transform: 'translateY(-3px)' }, transition: '0.3s' }}
            >
              <InstagramIcon />
            </IconButton>
            <IconButton
              href="https://twitter.com"
              target="_blank"
              sx={{ color: 'white', '&:hover': { color: '#1DA1F2', transform: 'translateY(-3px)' }, transition: '0.3s' }}
            >
              <TwitterIcon />
            </IconButton>
            <IconButton
              href="https://facebook.com"
              target="_blank"
              sx={{ color: 'white', '&:hover': { color: '#4267B2', transform: 'translateY(-3px)' }, transition: '0.3s' }}
            >
              <FacebookIcon />
            </IconButton>
          </Box>

          <Typography variant="caption" sx={{ color: '#888' }}>
            © {new Date().getFullYear()} HOODLY STREETWEAR. ALL RIGHTS RESERVED.
          </Typography>
        </Box>
      </Container>
    </Box>
  );
}