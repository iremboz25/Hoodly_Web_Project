import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import Badge from "@mui/material/Badge";
import Box from "@mui/material/Box";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Divider from "@mui/material/Divider";
import ListItemIcon from "@mui/material/ListItemIcon";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import Logout from "@mui/icons-material/Logout";
import SearchIcon from "@mui/icons-material/Search";
import InputBase from "@mui/material/InputBase";
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import { styled, alpha } from "@mui/material/styles";
import Button from "@mui/material/Button";

// Modern Icons
import Inventory2OutlinedIcon from '@mui/icons-material/Inventory2Outlined';
import HeadsetMicOutlinedIcon from '@mui/icons-material/HeadsetMicOutlined';
import ChatBubbleOutlineOutlinedIcon from '@mui/icons-material/ChatBubbleOutlineOutlined';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';

// Custom context hooks
import { useCart } from "../context/CartContext";
import { useWishlist } from "../context/WishlistContext";

const Search = styled("form")(({ theme }) => ({
  position: "relative",
  borderRadius: "4px",
  backgroundColor: alpha(theme.palette.common.white, 0.08),
  "&:hover": { backgroundColor: alpha(theme.palette.common.white, 0.12) },
  marginLeft: theme.spacing(2),
  marginRight: theme.spacing(1),
  display: "flex",
  alignItems: "center",
  width: "auto",
  border: "1px solid rgba(255,255,255,0.1)"
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: "100%",
  pointerEvents: "none",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  color: "#888"
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: "inherit",
  "& .MuiInputBase-input": {
    padding: theme.spacing(1, 1, 1, 0),
    transition: theme.transitions.create("width"),
    fontSize: "13px",
    fontWeight: 500,
    width: "15ch",
    [theme.breakpoints.up("md")]: {
      width: "25ch",
      "&:focus": { width: "40ch" },
    },
  },
}));

export default function Header() {
  const { items } = useCart();
  const { wishlistItems } = useWishlist();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();
  const open = Boolean(anchorEl);

  const handleOpenMenu = (event) => setAnchorEl(event.currentTarget);
  const handleCloseMenu = () => setAnchorEl(null);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim() !== "") {
      navigate(`/all-products?query=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery("");
    }
  };

  const totalCount = items.reduce((sum, it) => sum + (it.quantity || 1), 0);

  const navItems = [
    { text: 'ALL PRODUCTS', path: '/all-products' },
    { text: 'NEW DROPS', path: '/new-drops' },
    { text: 'GRAPHICS', path: '/graphics' },
    { text: 'ESSENTIALS', path: '/essentials' }
  ];

  return (
    <AppBar position="sticky" sx={{ bgcolor: '#121212', boxShadow: 'none', borderBottom: '1px solid #222' }}>
      <Toolbar sx={{ display: 'flex', justifyContent: 'space-between' }}>

        <Typography
          variant="h5"
          component={Link}
          to="/"
          sx={{ fontWeight: 900, letterSpacing: '5px', color: "white", textDecoration: "none", textTransform: "uppercase", flexShrink: 0 }}
        >
          HOODLY
        </Typography>

        <Box sx={{ display: { xs: 'none', lg: 'flex' }, gap: 3 }}>
          {navItems.map((item) => (
            <Typography
              key={item.text}
              component={Link}
              to={item.path}
              sx={{
                color: 'white',
                textDecoration: 'none',
                fontSize: '13px',
                fontWeight: 700,
                letterSpacing: '1px',
                '&:hover': { color: '#bbb' }
              }}
            >
              {item.text}
            </Typography>
          ))}
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>

          <Search onSubmit={handleSearchSubmit}>
            <SearchIconWrapper><SearchIcon fontSize="small" /></SearchIconWrapper>
            <StyledInputBase
              placeholder="SEARCH FOR PRODUCTS..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              inputProps={{ "aria-label": "search" }}
            />
          </Search>

          <IconButton onClick={handleOpenMenu} color="inherit" sx={{ ml: 1 }}>
            <PersonOutlineIcon />
          </IconButton>

          <IconButton color="inherit" component={Link} to="/wishlist">
            <Badge badgeContent={wishlistItems.length} color="error">
              <FavoriteBorderIcon />
            </Badge>
          </IconButton>

          <IconButton color="inherit" component={Link} to="/checkout">
            <Badge badgeContent={totalCount} color="error">
              <ShoppingCartIcon />
            </Badge>
          </IconButton>

          {/* ENGLISH DROPDOWN MENU */}
          <Menu
            anchorEl={anchorEl}
            open={open}
            onClose={handleCloseMenu}
            PaperProps={{
              sx: {
                width: 280,
                mt: 1.5,
                borderRadius: 0,
                bgcolor: '#1a1a1a',
                color: 'white',
                boxShadow: '0px 10px 20px rgba(0,0,0,0.5)',
                '& .MuiMenuItem-root': { fontSize: '14px', py: 1.2, fontWeight: 600 }
              }
            }}
          >
            {/* SIGN IN SECTION */}
            <Box sx={{ p: 2, display: 'flex', alignItems: 'center', gap: 2 }}>
              <Button
                variant="contained"
                fullWidth
                component={Link}
                to="/login"
                sx={{ bgcolor: '#fff', color: '#000', borderRadius: 0, fontWeight: 700, '&:hover': { bgcolor: '#ccc' } }}
              >
                Sign In
              </Button>
              <Typography
                component={Link}
                to="/register"
                sx={{ textDecoration: 'none', color: 'white', fontWeight: 600, fontSize: '0.8rem', whiteSpace: 'nowrap' }}
              >
                Create Account
              </Typography>
            </Box>

            <Divider sx={{ bgcolor: '#333' }} />

           <MenuItem
             onClick={() => {
               handleCloseMenu();
               navigate("/profile?view=info"); // URL'e parametre ekler
             }}
           >
             <ListItemIcon><PersonOutlineIcon fontSize="small" sx={{ color: 'white' }} /></ListItemIcon>
             My Account
           </MenuItem>


           <MenuItem
             onClick={() => {
               handleCloseMenu();
               navigate("/profile?view=orders"); // URL'e parametre ekler
             }}
           >
             <ListItemIcon><Inventory2OutlinedIcon fontSize="small" sx={{ color: 'white' }} /></ListItemIcon>
             Order History
           </MenuItem>

            <MenuItem onClick={handleCloseMenu}>
              <ListItemIcon><HeadsetMicOutlinedIcon fontSize="small" sx={{ color: 'white' }} /></ListItemIcon>
              Customer Service
            </MenuItem>

            <MenuItem onClick={handleCloseMenu}>
              <ListItemIcon><ChatBubbleOutlineOutlinedIcon fontSize="small" sx={{ color: 'white' }} /></ListItemIcon>
              Contact Us
            </MenuItem>

            <MenuItem onClick={handleCloseMenu} sx={{ color: '#25D366' }}>
              <ListItemIcon><WhatsAppIcon fontSize="small" sx={{ color: '#25D366' }} /></ListItemIcon>
              WhatsApp Support
            </MenuItem>

            <Divider sx={{ bgcolor: '#333' }} />

            <MenuItem onClick={handleCloseMenu}>
              <ListItemIcon><Logout fontSize="small" sx={{ color: 'white' }} /></ListItemIcon>
              Secure Logout
            </MenuItem>
          </Menu>
        </Box>
      </Toolbar>
    </AppBar>
  );
}