import React, { useState } from "react";
import Card from "@mui/material/Card";
import CardMedia from "@mui/material/CardMedia";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import CardActions from "@mui/material/CardActions";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import FavoriteIcon from "@mui/icons-material/Favorite";
import { useCart } from "../context/CartContext";
import { useWishlist } from "../context/WishlistContext";
import { resolveImageUrl } from "../config";
import { Link } from "react-router-dom";

export default function ProductCard({ product }) {
  const { add } = useCart();
  const { addToWishlist, removeFromWishlist, isFavorite } = useWishlist();

  // Menü konumu için state
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const favorite = isFavorite(product.id);

  const handleOpenMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleCloseMenu = () => {
    setAnchorEl(null);
  };

  const handleSelectSize = (size) => {
    add({ ...product, selectedSize: size });
    handleCloseMenu();
    // Opsiyonel: Buraya "Sepete Eklendi" uyarısı koyabilirsin
  };

  const handleFavoriteClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    favorite ? removeFromWishlist(product.id) : addToWishlist(product);
  };

  return (
    <Card
      sx={{
        maxWidth: 345,
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        position: 'relative',
        transition: 'all 0.4s ease-in-out',
        '&:hover': {
          transform: 'translateY(-10px)',
          boxShadow: '0px 10px 25px rgba(0,0,0,0.2)',
        }
      }}
    >
      <Box sx={{ position: 'relative', overflow: 'hidden' }}>
        <CardMedia
          component="img"
          height="160"
          image={resolveImageUrl(product.imageUrl)}
          alt={product.name}
          sx={{ transition: '0.5s', '&:hover': { transform: 'scale(1.1)' } }}
        />
        <IconButton
          onClick={handleFavoriteClick}
          sx={{ position: 'absolute', top: 5, right: 5, bgcolor: 'rgba(255, 255, 255, 0.7)' }}
        >
          {favorite ? <FavoriteIcon sx={{ color: "red" }} /> : <FavoriteBorderIcon />}
        </IconButton>
      </Box>

      <CardContent sx={{ flexGrow: 1 }}>
        <Typography gutterBottom variant="h6" sx={{ fontWeight: 700 }}>
          {product.name}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {product.description}
        </Typography>
        <Typography variant="subtitle1" sx={{ mt: 1, fontWeight: '900' }}>
          ${product.price.toFixed(2)}
        </Typography>
      </CardContent>

      <CardActions sx={{ justifyContent: 'space-between', px: 2, pb: 2 }}>
        {/* ADD TO CART BUTONU */}
        <Button
          variant="contained"
          size="small"
          onClick={handleOpenMenu}
          sx={{ bgcolor: 'black', borderRadius: 0, '&:hover': { bgcolor: '#333' } }}
        >
          Add to Cart
        </Button>

        {/* BEDEN SEÇİM MENÜSÜ */}
        <Menu
          anchorEl={anchorEl}
          open={open}
          onClose={handleCloseMenu}
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
          transformOrigin={{ vertical: 'bottom', horizontal: 'center' }}
          PaperProps={{ sx: { borderRadius: 0, minWidth: '100px' } }}
        >
          <MenuItem disabled sx={{ fontWeight: 'bold', fontSize: '11px' }}>SELECT SIZE</MenuItem>
          {['S', 'M', 'L', 'XL'].map((size) => (
            <MenuItem key={size} onClick={() => handleSelectSize(size)} sx={{ justifyContent: 'center' }}>
              {size}
            </MenuItem>
          ))}
        </Menu>

        <Button
          size="small"
          component={Link}
          to={`/products/${product.id}`}
          sx={{ color: 'black', textDecoration: 'underline' }}
        >
          View
        </Button>
      </CardActions>
    </Card>
  );
}